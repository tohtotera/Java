class Department {       // 部署クラス
    String name;  
    Employee leader;
}