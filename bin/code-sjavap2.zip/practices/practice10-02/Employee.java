class Employee {     // 社員クラス
    String name;  
    int age;
}