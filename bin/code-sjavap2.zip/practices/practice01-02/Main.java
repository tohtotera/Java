public class Main {
        
    /* 練習1-2の解答 ここから */
    String concatPath(String folder, String file) {
        if(!folder.endsWith("\\")) folder += "\\";
        return folder + file;
    }
    /* 練習1-2の解答 ここまで */
        
}