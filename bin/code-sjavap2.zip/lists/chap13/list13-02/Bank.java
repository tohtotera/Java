package jp.miyabilink.atm;

public class Bank {

}
