package jp.miyabilink.atm;

public class Account {
    public int transfer(Bank bank, Account dest, int amount) {
        return 0;
    }
}