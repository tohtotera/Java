public class Main {
    public static int twice(int x) { return x * 2; }
    /* 「1つのint値を受け取り、2倍にして、結果を返す関数」とも言える */
    public static int sub(int a, int b) { return a - b; }
    /* 「2つのint値を受け取り、その差を求め、結果を返す関数」とも言える */

}