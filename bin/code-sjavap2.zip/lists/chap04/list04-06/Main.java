import java.util.*;
public class Main {
    public static void main(String[] args) {
        List<Account> list = new ArrayList<Account>();
        /* : */
        Collections.sort(list);     /* これだけで要素が並び替えられる */
    }
}