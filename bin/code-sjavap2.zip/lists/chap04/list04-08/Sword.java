public class Sword {

}
