import java.io.*;

public class Hero implements Serializable {
    private static final long serialVersionUID = 81923983183821L;
    /* : */
}