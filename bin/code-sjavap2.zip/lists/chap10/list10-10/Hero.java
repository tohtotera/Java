import java.io.*;

public class Hero implements Serializable {
    private int hp;         // 基本データ型のフィールド
    private Sword sword;    // クラス型のフィールド
    /* : */
}