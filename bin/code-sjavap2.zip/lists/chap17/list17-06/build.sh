#!/bin/sh           'シェルスクリプトであることの宣言
javac *.java        'コンパイル
java AllTests       'テスト
javadoc *.java      'javadoc生成