import java.util.*;
public class Party {
    private Hero mainHero;              /* 勇者は必ず１人 */
    private List<Character> fellow;     /* 複数属する可能性があるため、コレクションを利用 */
    /* : */
}