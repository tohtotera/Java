class WeakOthelloAI implements OthelloAI {
	public int[] decide(int[][] board) {
		/* … 打てる場所を全て洗い出し、ランダムで選ぶ処理 … */
		return null;
	}
}