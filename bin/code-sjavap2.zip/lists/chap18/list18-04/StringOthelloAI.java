class StrongOthelloAI implements OthelloAI {
	public int[] decide(int[][] board) {
		/* … 盤の状態を詳しく分析して次の手を決める処理 … */
		return null;
	}
}