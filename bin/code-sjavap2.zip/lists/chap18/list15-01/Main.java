class Account {
    public Account(String omner) { /* … */ }
}

public class Main {
    public static void main(String[] args) {
        Account a = new Account("ミナト");
    }
}