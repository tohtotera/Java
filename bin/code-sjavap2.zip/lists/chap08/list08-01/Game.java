public class Game {
    public static void main(String[] args) {
        System.out.println("RPG: スッキリ魔王征伐 ver0.2");
        Hero h = new Hero();    /* 朝香ライブラリに含まれるHeroクラスを利用 */
        /* : */
    }
}