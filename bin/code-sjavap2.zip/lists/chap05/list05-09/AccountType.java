enum AccountType { FUTSU, TOUZA, TEIKI; }
