// 口座クラスです（湊ver）
public class Account {
    private String accountNo;
    private int balance;
    private String accountType;     /* 口座種別を文字列で受け取り格納 */
    public Account(String aNo, String aType) { /* … */ }
    /* : */
}
// 【利用例】new Account("1732050","普通");