public class Hero {

}
