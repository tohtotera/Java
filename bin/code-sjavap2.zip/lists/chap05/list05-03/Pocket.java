public class Pocket {
    private Object data;    // 格納用の変数
    public void put(Object d) { this.data = d; }
    public Object get() { return this.data; }
}
