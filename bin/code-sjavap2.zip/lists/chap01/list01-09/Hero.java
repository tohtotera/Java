public class Hero {
    String name;
    String job;
    int gold;
    
    public String getName() {
        return this.name;
    }
    public String getJob() {
        return this.job;
    }
    public int getGold() {
        return this.gold;
    }
}