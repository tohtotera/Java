public class Main {

    /* リスト1-6 ここから */
    boolean isValidPlayerName(String name) {
        return name.matches("[A-Z][A-Z0-9]{7}");    /* 文字列パターン */
    }
    /* リスト1-6 ここまで */

}